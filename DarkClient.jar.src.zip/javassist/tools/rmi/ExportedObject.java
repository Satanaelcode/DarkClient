package javassist.tools.rmi;

import java.lang.reflect.Method;

class ExportedObject {
  public int identifier;
  
  public Object object;
  
  public Method[] methods;
}


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\javassist\tools\rmi\ExportedObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */