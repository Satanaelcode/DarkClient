package javassist.tools.rmi;

public interface Proxy {
  int _getObjectId();
}


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\javassist\tools\rmi\Proxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */