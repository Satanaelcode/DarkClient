/*    */ package javassist.tools.reflect;
/*    */ 
/*    */ import javassist.CannotCompileException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CannotReflectException
/*    */   extends CannotCompileException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public CannotReflectException(String msg) {
/* 37 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\javassist\tools\reflect\CannotReflectException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */