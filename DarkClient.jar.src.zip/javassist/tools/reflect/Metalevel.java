package javassist.tools.reflect;

public interface Metalevel {
  ClassMetaobject _getClass();
  
  Metaobject _getMetaobject();
  
  void _setMetaobject(Metaobject paramMetaobject);
}


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\javassist\tools\reflect\Metalevel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */