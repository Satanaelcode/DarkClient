package javassist.tools.reflect;

class CompiledClass {
  public String classname;
  
  public String metaobject;
  
  public String classobject;
}


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\javassist\tools\reflect\CompiledClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */