package javassist.runtime;

public class Inner {}


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\javassist\runtime\Inner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */