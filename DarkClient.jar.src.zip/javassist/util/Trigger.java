package javassist.util;

class Trigger {
  void doSwap() {}
}


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\javassis\\util\Trigger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */