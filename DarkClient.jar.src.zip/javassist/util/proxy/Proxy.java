package javassist.util.proxy;

public interface Proxy {
  void setHandler(MethodHandler paramMethodHandler);
}


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\javassis\\util\proxy\Proxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */