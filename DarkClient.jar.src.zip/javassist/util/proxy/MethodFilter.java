package javassist.util.proxy;

import java.lang.reflect.Method;

public interface MethodFilter {
  boolean isHandled(Method paramMethod);
}


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\javassis\\util\proxy\MethodFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */