/*    */ package javassist.compiler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Token
/*    */ {
/* 20 */   public Token next = null;
/*    */   public int tokenId;
/*    */   public long longValue;
/*    */   public double doubleValue;
/*    */   public String textValue;
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\javassist\compiler\Token.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */