/*    */ package meteordevelopment.meteorclient.addons;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import net.fabricmc.loader.api.FabricLoader;
/*    */ import net.fabricmc.loader.api.ModContainer;
/*    */ import net.fabricmc.loader.api.entrypoint.EntrypointContainer;
/*    */ import net.fabricmc.loader.api.metadata.ModMetadata;
/*    */ import net.fabricmc.loader.api.metadata.Person;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AddonManager
/*    */ {
/* 18 */   public static final List<MeteorAddon> ADDONS = new ArrayList<>();
/*    */ 
/*    */ 
/*    */   
/*    */   public static void init() {
/* 23 */     MeteorClient.ADDON = new MeteorAddon()
/*    */       {
/*    */         public void onInitialize() {}
/*    */ 
/*    */         
/*    */         public String getPackage() {
/* 29 */           return "meteordevelopment.meteorclient";
/*    */         }
/*    */ 
/*    */         
/*    */         public String getWebsite() {
/* 34 */           return "https://meteorclient.com";
/*    */         }
/*    */ 
/*    */         
/*    */         public GithubRepo getRepo() {
/* 39 */           return new GithubRepo("MeteorDevelopment", "meteor-client");
/*    */         }
/*    */ 
/*    */         
/*    */         public String getCommit() {
/* 44 */           String commit = MeteorClient.MOD_META.getCustomValue("meteor-client:commit").getAsString();
/* 45 */           return commit.isEmpty() ? null : commit;
/*    */         }
/*    */       };
/*    */     
/* 49 */     ModMetadata metadata = ((ModContainer)FabricLoader.getInstance().getModContainer("meteor-client").get()).getMetadata();
/*    */     
/* 51 */     MeteorClient.ADDON.name = metadata.getName();
/* 52 */     MeteorClient.ADDON.authors = new String[metadata.getAuthors().size()];
/* 53 */     if (metadata.containsCustomValue("meteor-client:color")) {
/* 54 */       MeteorClient.ADDON.color.parse(metadata.getCustomValue("meteor-client:color").getAsString());
/*    */     }
/*    */     
/* 57 */     int i = 0;
/* 58 */     for (Person author : metadata.getAuthors()) {
/* 59 */       MeteorClient.ADDON.authors[i++] = author.getName();
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 64 */     for (EntrypointContainer<MeteorAddon> entrypoint : (Iterable<EntrypointContainer<MeteorAddon>>)FabricLoader.getInstance().getEntrypointContainers("meteor", MeteorAddon.class)) {
/* 65 */       ModMetadata modMetadata = entrypoint.getProvider().getMetadata();
/* 66 */       MeteorAddon addon = (MeteorAddon)entrypoint.getEntrypoint();
/*    */       
/* 68 */       addon.name = modMetadata.getName();
/*    */       
/* 70 */       if (modMetadata.getAuthors().isEmpty()) throw new RuntimeException("Addon %s requires at least 1 author to be defined in it's fabric.mod.json. See https://fabricmc.net/wiki/documentation:fabric_mod_json_spec".formatted(new Object[] { addon.name })); 
/* 71 */       addon.authors = new String[modMetadata.getAuthors().size()];
/*    */       
/* 73 */       if (modMetadata.containsCustomValue("meteor-client:color")) {
/* 74 */         addon.color.parse(modMetadata.getCustomValue("meteor-client:color").getAsString());
/*    */       }
/*    */       
/* 77 */       int j = 0;
/* 78 */       for (Person author : modMetadata.getAuthors()) {
/* 79 */         addon.authors[j++] = author.getName();
/*    */       }
/*    */       
/* 82 */       ADDONS.add(addon);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\addons\AddonManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */