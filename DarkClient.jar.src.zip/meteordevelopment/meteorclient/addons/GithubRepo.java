/*    */ package meteordevelopment.meteorclient.addons;
/*    */ public final class GithubRepo extends Record { private final String owner; private final String name; private final String branch; public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lmeteordevelopment/meteorclient/addons/GithubRepo;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #8	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lmeteordevelopment/meteorclient/addons/GithubRepo;
/*    */   }
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lmeteordevelopment/meteorclient/addons/GithubRepo;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #8	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lmeteordevelopment/meteorclient/addons/GithubRepo;
/*    */   }
/*  8 */   public GithubRepo(String owner, String name, String branch) { this.owner = owner; this.name = name; this.branch = branch; } public final boolean equals(Object o) { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lmeteordevelopment/meteorclient/addons/GithubRepo;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #8	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lmeteordevelopment/meteorclient/addons/GithubRepo;
/*  8 */     //   0	8	1	o	Ljava/lang/Object; } public String owner() { return this.owner; } public String name() { return this.name; } public String branch() { return this.branch; }
/*    */    public GithubRepo(String owner, String name) {
/* 10 */     this(owner, name, "master");
/*    */   }
/*    */   
/*    */   public String getOwnerName() {
/* 14 */     return this.owner + "/" + this.owner;
/*    */   } }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\addons\GithubRepo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */