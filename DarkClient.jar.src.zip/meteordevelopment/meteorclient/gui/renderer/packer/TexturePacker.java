/*     */ package meteordevelopment.meteorclient.gui.renderer.packer;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.TextureUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import meteordevelopment.meteorclient.MeteorClient;
/*     */ import meteordevelopment.meteorclient.utils.render.ByteTexture;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_3298;
/*     */ import org.lwjgl.BufferUtils;
/*     */ import org.lwjgl.stb.STBImage;
/*     */ import org.lwjgl.stb.STBImageResize;
/*     */ import org.lwjgl.system.MemoryStack;
/*     */ import org.lwjgl.system.MemoryUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TexturePacker
/*     */ {
/*     */   private static final int maxWidth = 2048;
/*  30 */   private final List<Image> images = new ArrayList<>();
/*     */   
/*     */   public GuiTexture add(class_2960 id) {
/*     */     try {
/*  34 */       InputStream in = ((class_3298)MeteorClient.mc.method_1478().method_14486(id).get()).method_14482();
/*  35 */       GuiTexture texture = new GuiTexture();
/*     */       
/*  37 */       MemoryStack stack = MemoryStack.stackPush(); 
/*  38 */       try { ByteBuffer rawImageBuffer = null;
/*     */         
/*     */         try {
/*  41 */           rawImageBuffer = TextureUtil.readResource(in);
/*  42 */           rawImageBuffer.rewind();
/*     */           
/*  44 */           IntBuffer w = stack.mallocInt(1);
/*  45 */           IntBuffer h = stack.mallocInt(1);
/*  46 */           IntBuffer ignored = stack.mallocInt(1);
/*     */           
/*  48 */           ByteBuffer imageBuffer = STBImage.stbi_load_from_memory(rawImageBuffer, w, h, ignored, 4);
/*     */           
/*  50 */           int width = w.get(0);
/*  51 */           int height = h.get(0);
/*     */           
/*  53 */           TextureRegion region = new TextureRegion(width, height);
/*  54 */           texture.add(region);
/*     */           
/*  56 */           this.images.add(new Image(imageBuffer, region, width, height, true));
/*     */           
/*  58 */           if (width > 20) addResized(texture, imageBuffer, width, height, 20); 
/*  59 */           if (width > 32) addResized(texture, imageBuffer, width, height, 32); 
/*  60 */           if (width > 48) addResized(texture, imageBuffer, width, height, 48); 
/*  61 */         } catch (IOException e) {
/*  62 */           e.printStackTrace();
/*     */         } finally {
/*  64 */           MemoryUtil.memFree(rawImageBuffer);
/*     */         } 
/*  66 */         if (stack != null) stack.close();  } catch (Throwable throwable) { if (stack != null)
/*     */           try { stack.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/*  68 */        return texture;
/*  69 */     } catch (IOException e) {
/*  70 */       e.printStackTrace();
/*     */ 
/*     */       
/*  73 */       return null;
/*     */     } 
/*     */   }
/*     */   private void addResized(GuiTexture texture, ByteBuffer srcImageBuffer, int srcWidth, int srcHeight, int width) {
/*  77 */     double scaleFactor = width / srcWidth;
/*  78 */     int height = (int)(srcHeight * scaleFactor);
/*     */     
/*  80 */     ByteBuffer imageBuffer = BufferUtils.createByteBuffer(width * height * 4);
/*  81 */     STBImageResize.stbir_resize_uint8(srcImageBuffer, srcWidth, srcHeight, 0, imageBuffer, width, height, 0, 4);
/*     */     
/*  83 */     TextureRegion region = new TextureRegion(width, height);
/*  84 */     texture.add(region);
/*     */     
/*  86 */     this.images.add(new Image(imageBuffer, region, width, height, false));
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteTexture pack() {
/*  91 */     int width = 0;
/*  92 */     int height = 0;
/*     */     
/*  94 */     int rowWidth = 0;
/*  95 */     int rowHeight = 0;
/*     */     
/*  97 */     for (Image image : this.images) {
/*  98 */       if (rowWidth + image.width > 2048) {
/*  99 */         width = Math.max(width, rowWidth);
/* 100 */         height += rowHeight;
/*     */         
/* 102 */         rowWidth = 0;
/* 103 */         rowHeight = 0;
/*     */       } 
/*     */       
/* 106 */       image.x = 1 + rowWidth;
/* 107 */       image.y = 1 + height;
/*     */       
/* 109 */       rowWidth += 1 + image.width + 1;
/* 110 */       rowHeight = Math.max(rowHeight, 1 + image.height + 1);
/*     */     } 
/*     */     
/* 113 */     width = Math.max(width, rowWidth);
/* 114 */     height += rowHeight;
/*     */ 
/*     */     
/* 117 */     ByteBuffer buffer = BufferUtils.createByteBuffer(width * height * 4);
/*     */     
/* 119 */     for (Image image : this.images) {
/*     */       
/* 121 */       byte[] row = new byte[image.width * 4];
/*     */       
/* 123 */       for (int i = 0; i < image.height; i++) {
/* 124 */         image.buffer.position(i * row.length);
/* 125 */         image.buffer.get(row);
/*     */         
/* 127 */         buffer.position(((image.y + i) * width + image.x) * 4);
/* 128 */         buffer.put(row);
/*     */       } 
/*     */       
/* 131 */       image.buffer.rewind();
/* 132 */       image.free();
/*     */ 
/*     */       
/* 135 */       image.region.x1 = image.x / width;
/* 136 */       image.region.y1 = image.y / height;
/* 137 */       image.region.x2 = (image.x + image.width) / width;
/* 138 */       image.region.y2 = (image.y + image.height) / height;
/*     */     } 
/*     */     
/* 141 */     buffer.rewind();
/* 142 */     return new ByteTexture(width, height, buffer, ByteTexture.Format.RGBA, ByteTexture.Filter.Linear, ByteTexture.Filter.Linear);
/*     */   }
/*     */   
/*     */   private static class Image
/*     */   {
/*     */     public final ByteBuffer buffer;
/*     */     public final TextureRegion region;
/*     */     public final int width;
/*     */     public final int height;
/*     */     public int x;
/*     */     public int y;
/*     */     private final boolean stb;
/*     */     
/*     */     public Image(ByteBuffer buffer, TextureRegion region, int width, int height, boolean stb) {
/* 156 */       this.buffer = buffer;
/* 157 */       this.region = region;
/* 158 */       this.width = width;
/* 159 */       this.height = height;
/* 160 */       this.stb = stb;
/*     */     }
/*     */     
/*     */     public void free() {
/* 164 */       if (this.stb) STBImage.stbi_image_free(this.buffer); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\gui\renderer\packer\TexturePacker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */