/*    */ package meteordevelopment.meteorclient.gui.renderer.operations;
/*    */ 
/*    */ import meteordevelopment.meteorclient.gui.renderer.GuiRenderOperation;
/*    */ import meteordevelopment.meteorclient.renderer.text.TextRenderer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextOperation
/*    */   extends GuiRenderOperation<TextOperation>
/*    */ {
/*    */   private String text;
/*    */   private TextRenderer renderer;
/*    */   public boolean title;
/*    */   
/*    */   public TextOperation set(String text, TextRenderer renderer, boolean title) {
/* 18 */     this.text = text;
/* 19 */     this.renderer = renderer;
/* 20 */     this.title = title;
/*    */     
/* 22 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void onRun() {
/* 27 */     this.renderer.render(this.text, this.x, this.y, this.color);
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\gui\renderer\operations\TextOperation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */