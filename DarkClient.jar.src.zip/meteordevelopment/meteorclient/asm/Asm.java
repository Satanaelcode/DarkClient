/*     */ package meteordevelopment.meteorclient.asm;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import meteordevelopment.meteorclient.asm.transformers.CanvasWorldRendererTransformer;
/*     */ import meteordevelopment.meteorclient.asm.transformers.GameRendererTransformer;
/*     */ import net.fabricmc.loader.api.FabricLoader;
/*     */ import org.objectweb.asm.ClassReader;
/*     */ import org.objectweb.asm.ClassVisitor;
/*     */ import org.objectweb.asm.tree.ClassNode;
/*     */ import org.spongepowered.asm.mixin.MixinEnvironment;
/*     */ import org.spongepowered.asm.mixin.transformer.IMixinTransformer;
/*     */ import org.spongepowered.asm.mixin.transformer.ext.IExtensionRegistry;
/*     */ import org.spongepowered.asm.transformers.MixinClassWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Asm
/*     */ {
/*     */   public static Asm INSTANCE;
/*  31 */   private final Map<String, AsmTransformer> transformers = new HashMap<>();
/*     */   private final boolean export;
/*     */   
/*     */   public Asm(boolean export) {
/*  35 */     this.export = export;
/*     */   }
/*     */   
/*     */   public static void init() {
/*  39 */     if (INSTANCE != null)
/*     */       return; 
/*  41 */     INSTANCE = new Asm((System.getProperty("meteor.asm.export") != null));
/*  42 */     INSTANCE.add((AsmTransformer)new GameRendererTransformer());
/*  43 */     INSTANCE.add((AsmTransformer)new CanvasWorldRendererTransformer());
/*     */   }
/*     */   
/*     */   private void add(AsmTransformer transformer) {
/*  47 */     this.transformers.put(transformer.targetName, transformer);
/*     */   }
/*     */   
/*     */   public byte[] transform(String name, byte[] bytes) {
/*  51 */     AsmTransformer transformer = this.transformers.get(name);
/*     */     
/*  53 */     if (transformer != null) {
/*  54 */       ClassNode klass = new ClassNode();
/*  55 */       ClassReader reader = new ClassReader(bytes);
/*  56 */       reader.accept((ClassVisitor)klass, 8);
/*     */       
/*  58 */       transformer.transform(klass);
/*     */       
/*  60 */       MixinClassWriter mixinClassWriter = new MixinClassWriter(reader, 2);
/*  61 */       klass.accept((ClassVisitor)mixinClassWriter);
/*  62 */       bytes = mixinClassWriter.toByteArray();
/*     */       
/*  64 */       export(name, bytes);
/*     */     } 
/*     */     
/*  67 */     return bytes;
/*     */   }
/*     */   
/*     */   private void export(String name, byte[] bytes) {
/*  71 */     if (this.export)
/*     */       try {
/*  73 */         Path path = Path.of(FabricLoader.getInstance().getGameDir().toString(), new String[] { ".meteor.asm.out", name.replace('.', '/') + ".class" });
/*  74 */         (new File(path.toUri())).getParentFile().mkdirs();
/*  75 */         Files.write(path, bytes, new java.nio.file.OpenOption[0]);
/*  76 */       } catch (IOException e) {
/*  77 */         e.printStackTrace();
/*     */       }  
/*     */   }
/*     */   
/*     */   public static class Transformer
/*     */     implements IMixinTransformer
/*     */   {
/*     */     public IMixinTransformer delegate;
/*     */     
/*     */     public void audit(MixinEnvironment environment) {
/*  87 */       this.delegate.audit(environment);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> reload(String mixinClass, ClassNode classNode) {
/*  92 */       return this.delegate.reload(mixinClass, classNode);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean computeFramesForClass(MixinEnvironment environment, String name, ClassNode classNode) {
/*  97 */       return this.delegate.computeFramesForClass(environment, name, classNode);
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] transformClassBytes(String name, String transformedName, byte[] basicClass) {
/* 102 */       basicClass = this.delegate.transformClassBytes(name, transformedName, basicClass);
/* 103 */       return Asm.INSTANCE.transform(name, basicClass);
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] transformClass(MixinEnvironment environment, String name, byte[] classBytes) {
/* 108 */       return this.delegate.transformClass(environment, name, classBytes);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean transformClass(MixinEnvironment environment, String name, ClassNode classNode) {
/* 113 */       return this.delegate.transformClass(environment, name, classNode);
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] generateClass(MixinEnvironment environment, String name) {
/* 118 */       return this.delegate.generateClass(environment, name);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean generateClass(MixinEnvironment environment, String name, ClassNode classNode) {
/* 123 */       return this.delegate.generateClass(environment, name, classNode);
/*     */     }
/*     */ 
/*     */     
/*     */     public IExtensionRegistry getExtensions() {
/* 128 */       return this.delegate.getExtensions();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\asm\Asm.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */