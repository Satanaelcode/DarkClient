/*     */ package meteordevelopment.meteorclient.asm;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.objectweb.asm.tree.ClassNode;
/*     */ import org.spongepowered.asm.mixin.MixinEnvironment;
/*     */ import org.spongepowered.asm.mixin.transformer.IMixinTransformer;
/*     */ import org.spongepowered.asm.mixin.transformer.ext.IExtensionRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Transformer
/*     */   implements IMixinTransformer
/*     */ {
/*     */   public IMixinTransformer delegate;
/*     */   
/*     */   public void audit(MixinEnvironment environment) {
/*  87 */     this.delegate.audit(environment);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> reload(String mixinClass, ClassNode classNode) {
/*  92 */     return this.delegate.reload(mixinClass, classNode);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean computeFramesForClass(MixinEnvironment environment, String name, ClassNode classNode) {
/*  97 */     return this.delegate.computeFramesForClass(environment, name, classNode);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] transformClassBytes(String name, String transformedName, byte[] basicClass) {
/* 102 */     basicClass = this.delegate.transformClassBytes(name, transformedName, basicClass);
/* 103 */     return Asm.INSTANCE.transform(name, basicClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] transformClass(MixinEnvironment environment, String name, byte[] classBytes) {
/* 108 */     return this.delegate.transformClass(environment, name, classBytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean transformClass(MixinEnvironment environment, String name, ClassNode classNode) {
/* 113 */     return this.delegate.transformClass(environment, name, classNode);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] generateClass(MixinEnvironment environment, String name) {
/* 118 */     return this.delegate.generateClass(environment, name);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean generateClass(MixinEnvironment environment, String name, ClassNode classNode) {
/* 123 */     return this.delegate.generateClass(environment, name, classNode);
/*     */   }
/*     */ 
/*     */   
/*     */   public IExtensionRegistry getExtensions() {
/* 128 */     return this.delegate.getExtensions();
/*     */   }
/*     */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\asm\Asm$Transformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */