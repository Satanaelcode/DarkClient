/*    */ package meteordevelopment.meteorclient.asm.transformers;
/*    */ 
/*    */ import java.util.ListIterator;
/*    */ import meteordevelopment.meteorclient.asm.AsmTransformer;
/*    */ import meteordevelopment.meteorclient.asm.Descriptor;
/*    */ import meteordevelopment.meteorclient.asm.MethodInfo;
/*    */ import org.objectweb.asm.tree.AbstractInsnNode;
/*    */ import org.objectweb.asm.tree.ClassNode;
/*    */ import org.objectweb.asm.tree.MethodInsnNode;
/*    */ import org.objectweb.asm.tree.MethodNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CanvasWorldRendererTransformer
/*    */   extends AsmTransformer
/*    */ {
/*    */   private final MethodInfo renderWorldMethod;
/*    */   private final MethodInfo drawMethod;
/*    */   
/*    */   public CanvasWorldRendererTransformer() {
/* 21 */     super("grondag.canvas.render.world.CanvasWorldRenderer");
/*    */     
/* 23 */     this.renderWorldMethod = new MethodInfo(null, "renderWorld", null, false);
/*    */ 
/*    */     
/* 26 */     this.drawMethod = new MethodInfo("net/minecraft/class_4618", "method_23285", new Descriptor(new String[] { "V" }, ), true);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void transform(ClassNode klass) {
/* 32 */     MethodNode method = getMethod(klass, this.renderWorldMethod);
/* 33 */     if (method == null)
/*    */       return; 
/* 35 */     for (ListIterator<AbstractInsnNode> listIterator = method.instructions.iterator(); listIterator.hasNext(); ) { AbstractInsnNode insn = listIterator.next();
/* 36 */       if (insn instanceof MethodInsnNode) { MethodInsnNode in = (MethodInsnNode)insn;
/*    */         
/* 38 */         if (this.drawMethod.equals(in)) {
/* 39 */           method.instructions.insert(insn, (AbstractInsnNode)new MethodInsnNode(184, "meteordevelopment/meteorclient/utils/render/postprocess/PostProcessShaders", "endRender", "()V"));
/*    */           break;
/*    */         }  }
/*    */        }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\asm\transformers\CanvasWorldRendererTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */