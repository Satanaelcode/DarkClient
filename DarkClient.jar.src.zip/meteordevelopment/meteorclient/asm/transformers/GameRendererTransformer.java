/*    */ package meteordevelopment.meteorclient.asm.transformers;
/*    */ 
/*    */ import meteordevelopment.meteorclient.asm.AsmTransformer;
/*    */ import meteordevelopment.meteorclient.asm.Descriptor;
/*    */ import meteordevelopment.meteorclient.asm.MethodInfo;
/*    */ import org.objectweb.asm.tree.AbstractInsnNode;
/*    */ import org.objectweb.asm.tree.ClassNode;
/*    */ import org.objectweb.asm.tree.FieldInsnNode;
/*    */ import org.objectweb.asm.tree.InsnList;
/*    */ import org.objectweb.asm.tree.MethodInsnNode;
/*    */ import org.objectweb.asm.tree.TypeInsnNode;
/*    */ 
/*    */ public class GameRendererTransformer
/*    */   extends AsmTransformer {
/*    */   private final MethodInfo getFovMethod;
/*    */   
/*    */   public GameRendererTransformer() {
/* 18 */     super(mapClassName("net/minecraft/class_757"));
/*    */     
/* 20 */     this.getFovMethod = new MethodInfo("net/minecraft/class_4184", null, new Descriptor(new String[] { "Lnet/minecraft/class_4184;", "F", "Z", "D" }, ), true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void transform(ClassNode klass) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: aload_0
/*    */     //   3: getfield getFovMethod : Lmeteordevelopment/meteorclient/asm/MethodInfo;
/*    */     //   6: invokevirtual getMethod : (Lorg/objectweb/asm/tree/ClassNode;Lmeteordevelopment/meteorclient/asm/MethodInfo;)Lorg/objectweb/asm/tree/MethodNode;
/*    */     //   9: astore_2
/*    */     //   10: aload_2
/*    */     //   11: ifnonnull -> 24
/*    */     //   14: new java/lang/RuntimeException
/*    */     //   17: dup
/*    */     //   18: ldc '[Meteor Client] Could not find method GameRenderer.getFov()'
/*    */     //   20: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   23: athrow
/*    */     //   24: iconst_0
/*    */     //   25: istore_3
/*    */     //   26: aload_2
/*    */     //   27: getfield instructions : Lorg/objectweb/asm/tree/InsnList;
/*    */     //   30: invokevirtual iterator : ()Ljava/util/ListIterator;
/*    */     //   33: astore #4
/*    */     //   35: aload #4
/*    */     //   37: invokeinterface hasNext : ()Z
/*    */     //   42: ifeq -> 337
/*    */     //   45: aload #4
/*    */     //   47: invokeinterface next : ()Ljava/lang/Object;
/*    */     //   52: checkcast org/objectweb/asm/tree/AbstractInsnNode
/*    */     //   55: astore #5
/*    */     //   57: aload #5
/*    */     //   59: instanceof org/objectweb/asm/tree/LdcInsnNode
/*    */     //   62: ifeq -> 154
/*    */     //   65: aload #5
/*    */     //   67: checkcast org/objectweb/asm/tree/LdcInsnNode
/*    */     //   70: astore #6
/*    */     //   72: aload #6
/*    */     //   74: getfield cst : Ljava/lang/Object;
/*    */     //   77: instanceof java/lang/Double
/*    */     //   80: ifeq -> 154
/*    */     //   83: aload #6
/*    */     //   85: getfield cst : Ljava/lang/Object;
/*    */     //   88: checkcast java/lang/Double
/*    */     //   91: invokevirtual doubleValue : ()D
/*    */     //   94: ldc2_w 90.0
/*    */     //   97: dcmpl
/*    */     //   98: ifne -> 154
/*    */     //   101: new org/objectweb/asm/tree/InsnList
/*    */     //   104: dup
/*    */     //   105: invokespecial <init> : ()V
/*    */     //   108: astore #10
/*    */     //   110: aload_0
/*    */     //   111: aload #10
/*    */     //   113: new org/objectweb/asm/tree/LdcInsnNode
/*    */     //   116: dup
/*    */     //   117: aload #6
/*    */     //   119: getfield cst : Ljava/lang/Object;
/*    */     //   122: invokespecial <init> : (Ljava/lang/Object;)V
/*    */     //   125: invokevirtual generateEventCall : (Lorg/objectweb/asm/tree/InsnList;Lorg/objectweb/asm/tree/AbstractInsnNode;)V
/*    */     //   128: aload_2
/*    */     //   129: getfield instructions : Lorg/objectweb/asm/tree/InsnList;
/*    */     //   132: aload #5
/*    */     //   134: aload #10
/*    */     //   136: invokevirtual insert : (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/InsnList;)V
/*    */     //   139: aload_2
/*    */     //   140: getfield instructions : Lorg/objectweb/asm/tree/InsnList;
/*    */     //   143: aload #5
/*    */     //   145: invokevirtual remove : (Lorg/objectweb/asm/tree/AbstractInsnNode;)V
/*    */     //   148: iinc #3, 1
/*    */     //   151: goto -> 334
/*    */     //   154: aload #5
/*    */     //   156: instanceof org/objectweb/asm/tree/MethodInsnNode
/*    */     //   159: ifeq -> 215
/*    */     //   162: aload #5
/*    */     //   164: checkcast org/objectweb/asm/tree/MethodInsnNode
/*    */     //   167: astore #7
/*    */     //   169: aload #7
/*    */     //   171: getfield name : Ljava/lang/String;
/*    */     //   174: ldc 'intValue'
/*    */     //   176: invokevirtual equals : (Ljava/lang/Object;)Z
/*    */     //   179: ifeq -> 215
/*    */     //   182: aload #5
/*    */     //   184: invokevirtual getNext : ()Lorg/objectweb/asm/tree/AbstractInsnNode;
/*    */     //   187: astore #10
/*    */     //   189: aload #10
/*    */     //   191: instanceof org/objectweb/asm/tree/InsnNode
/*    */     //   194: ifeq -> 215
/*    */     //   197: aload #10
/*    */     //   199: checkcast org/objectweb/asm/tree/InsnNode
/*    */     //   202: astore #8
/*    */     //   204: aload #8
/*    */     //   206: invokevirtual getOpcode : ()I
/*    */     //   209: sipush #135
/*    */     //   212: if_icmpeq -> 271
/*    */     //   215: aload #5
/*    */     //   217: instanceof org/objectweb/asm/tree/MethodInsnNode
/*    */     //   220: ifeq -> 334
/*    */     //   223: aload #5
/*    */     //   225: checkcast org/objectweb/asm/tree/MethodInsnNode
/*    */     //   228: astore #9
/*    */     //   230: aload #9
/*    */     //   232: getfield owner : Ljava/lang/String;
/*    */     //   235: aload_1
/*    */     //   236: getfield name : Ljava/lang/String;
/*    */     //   239: invokevirtual equals : (Ljava/lang/Object;)Z
/*    */     //   242: ifeq -> 334
/*    */     //   245: aload #9
/*    */     //   247: getfield name : Ljava/lang/String;
/*    */     //   250: ldc 'redirect'
/*    */     //   252: invokevirtual startsWith : (Ljava/lang/String;)Z
/*    */     //   255: ifeq -> 334
/*    */     //   258: aload #9
/*    */     //   260: getfield name : Ljava/lang/String;
/*    */     //   263: ldc 'getFov'
/*    */     //   265: invokevirtual endsWith : (Ljava/lang/String;)Z
/*    */     //   268: ifeq -> 334
/*    */     //   271: new org/objectweb/asm/tree/InsnList
/*    */     //   274: dup
/*    */     //   275: invokespecial <init> : ()V
/*    */     //   278: astore #10
/*    */     //   280: aload #10
/*    */     //   282: new org/objectweb/asm/tree/VarInsnNode
/*    */     //   285: dup
/*    */     //   286: bipush #57
/*    */     //   288: aload_2
/*    */     //   289: getfield maxLocals : I
/*    */     //   292: invokespecial <init> : (II)V
/*    */     //   295: invokevirtual add : (Lorg/objectweb/asm/tree/AbstractInsnNode;)V
/*    */     //   298: aload_0
/*    */     //   299: aload #10
/*    */     //   301: new org/objectweb/asm/tree/VarInsnNode
/*    */     //   304: dup
/*    */     //   305: bipush #24
/*    */     //   307: aload_2
/*    */     //   308: getfield maxLocals : I
/*    */     //   311: invokespecial <init> : (II)V
/*    */     //   314: invokevirtual generateEventCall : (Lorg/objectweb/asm/tree/InsnList;Lorg/objectweb/asm/tree/AbstractInsnNode;)V
/*    */     //   317: aload_2
/*    */     //   318: getfield instructions : Lorg/objectweb/asm/tree/InsnList;
/*    */     //   321: aload #5
/*    */     //   323: invokevirtual getNext : ()Lorg/objectweb/asm/tree/AbstractInsnNode;
/*    */     //   326: aload #10
/*    */     //   328: invokevirtual insert : (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/InsnList;)V
/*    */     //   331: iinc #3, 1
/*    */     //   334: goto -> 35
/*    */     //   337: iload_3
/*    */     //   338: iconst_2
/*    */     //   339: if_icmpge -> 352
/*    */     //   342: new java/lang/RuntimeException
/*    */     //   345: dup
/*    */     //   346: ldc '[Meteor Client] Failed to modify GameRenderer.getFov()'
/*    */     //   348: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   351: athrow
/*    */     //   352: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #26	-> 0
/*    */     //   #27	-> 10
/*    */     //   #29	-> 24
/*    */     //   #31	-> 26
/*    */     //   #32	-> 57
/*    */     //   #33	-> 101
/*    */     //   #34	-> 110
/*    */     //   #36	-> 128
/*    */     //   #37	-> 139
/*    */     //   #38	-> 148
/*    */     //   #39	-> 151
/*    */     //   #40	-> 154
/*    */     //   #41	-> 162
/*    */     //   #43	-> 223
/*    */     //   #45	-> 271
/*    */     //   #47	-> 280
/*    */     //   #48	-> 298
/*    */     //   #50	-> 317
/*    */     //   #51	-> 331
/*    */     //   #53	-> 334
/*    */     //   #55	-> 337
/*    */     //   #56	-> 352
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   110	41	10	insns	Lorg/objectweb/asm/tree/InsnList;
/*    */     //   72	82	6	in	Lorg/objectweb/asm/tree/LdcInsnNode;
/*    */     //   169	46	7	in1	Lorg/objectweb/asm/tree/MethodInsnNode;
/*    */     //   204	11	8	_in	Lorg/objectweb/asm/tree/InsnNode;
/*    */     //   230	41	9	in2	Lorg/objectweb/asm/tree/MethodInsnNode;
/*    */     //   280	54	10	insns	Lorg/objectweb/asm/tree/InsnList;
/*    */     //   57	277	5	insn	Lorg/objectweb/asm/tree/AbstractInsnNode;
/*    */     //   0	353	0	this	Lmeteordevelopment/meteorclient/asm/transformers/GameRendererTransformer;
/*    */     //   0	353	1	klass	Lorg/objectweb/asm/tree/ClassNode;
/*    */     //   10	343	2	method	Lorg/objectweb/asm/tree/MethodNode;
/*    */     //   26	327	3	injectionCount	I
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void generateEventCall(InsnList insns, AbstractInsnNode loadPreviousFov) {
/* 59 */     insns.add((AbstractInsnNode)new FieldInsnNode(178, "meteordevelopment/meteorclient/MeteorClient", "EVENT_BUS", "Lmeteordevelopment/orbit/IEventBus;"));
/* 60 */     insns.add(loadPreviousFov);
/* 61 */     insns.add((AbstractInsnNode)new MethodInsnNode(184, "meteordevelopment/meteorclient/events/render/GetFovEvent", "get", "(D)Lmeteordevelopment/meteorclient/events/render/GetFovEvent;"));
/* 62 */     insns.add((AbstractInsnNode)new MethodInsnNode(185, "meteordevelopment/orbit/IEventBus", "post", "(Ljava/lang/Object;)Ljava/lang/Object;"));
/* 63 */     insns.add((AbstractInsnNode)new TypeInsnNode(192, "meteordevelopment/meteorclient/events/render/GetFovEvent"));
/* 64 */     insns.add((AbstractInsnNode)new FieldInsnNode(180, "meteordevelopment/meteorclient/events/render/GetFovEvent", "fov", "D"));
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\asm\transformers\GameRendererTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */