/*    */ package meteordevelopment.meteorclient.asm;
/*    */ 
/*    */ import net.fabricmc.loader.api.FabricLoader;
/*    */ import org.objectweb.asm.tree.ClassNode;
/*    */ import org.objectweb.asm.tree.MethodNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AsmTransformer
/*    */ {
/*    */   public final String targetName;
/*    */   
/*    */   protected AsmTransformer(String targetName) {
/* 16 */     this.targetName = targetName;
/*    */   }
/*    */   
/*    */   public abstract void transform(ClassNode paramClassNode);
/*    */   
/*    */   protected MethodNode getMethod(ClassNode klass, MethodInfo methodInfo) {
/* 22 */     for (MethodNode method : klass.methods) {
/* 23 */       if (methodInfo.equals(method)) return method;
/*    */     
/*    */     } 
/* 26 */     return null;
/*    */   }
/*    */   
/*    */   protected static String mapClassName(String name) {
/* 30 */     return FabricLoader.getInstance().getMappingResolver().mapClassName("intermediary", name.replace('/', '.'));
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\asm\AsmTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */