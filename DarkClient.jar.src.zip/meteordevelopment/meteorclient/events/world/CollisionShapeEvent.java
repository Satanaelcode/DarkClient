/*    */ package meteordevelopment.meteorclient.events.world;
/*    */ 
/*    */ import meteordevelopment.meteorclient.events.Cancellable;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_265;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CollisionShapeEvent
/*    */   extends Cancellable
/*    */ {
/*    */   public enum CollisionType
/*    */   {
/* 15 */     BLOCK,
/* 16 */     FLUID;
/*    */   }
/*    */   
/* 19 */   private static final CollisionShapeEvent INSTANCE = new CollisionShapeEvent();
/*    */   
/*    */   public class_2680 state;
/*    */   public class_2338 pos;
/*    */   public class_265 shape;
/*    */   public CollisionType type;
/*    */   
/*    */   public static CollisionShapeEvent get(class_2680 state, class_2338 pos, class_265 shape, CollisionType type) {
/* 27 */     INSTANCE.state = state;
/* 28 */     INSTANCE.pos = pos;
/* 29 */     INSTANCE.shape = shape;
/* 30 */     INSTANCE.type = type;
/* 31 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\world\CollisionShapeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */