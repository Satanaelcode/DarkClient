/*    */ package meteordevelopment.meteorclient.events.world;
/*    */ 
/*    */ import meteordevelopment.meteorclient.utils.misc.Pool;
/*    */ import meteordevelopment.meteorclient.utils.misc.Producer;
/*    */ import net.minecraft.class_2818;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChunkDataEvent
/*    */ {
/* 12 */   private static final Pool<ChunkDataEvent> INSTANCE = new Pool(ChunkDataEvent::new);
/*    */   
/*    */   public class_2818 chunk;
/*    */   
/*    */   public static ChunkDataEvent get(class_2818 chunk) {
/* 17 */     ChunkDataEvent event = (ChunkDataEvent)INSTANCE.get();
/* 18 */     event.chunk = chunk;
/* 19 */     return event;
/*    */   }
/*    */   
/*    */   public static void returnChunkDataEvent(ChunkDataEvent event) {
/* 23 */     INSTANCE.free(event);
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\world\ChunkDataEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */