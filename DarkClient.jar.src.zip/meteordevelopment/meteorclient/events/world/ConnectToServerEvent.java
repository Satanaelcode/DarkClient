/*    */ package meteordevelopment.meteorclient.events.world;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConnectToServerEvent
/*    */ {
/*  9 */   private static final ConnectToServerEvent INSTANCE = new ConnectToServerEvent();
/*    */   
/*    */   public static ConnectToServerEvent get() {
/* 12 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\world\ConnectToServerEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */