/*    */ package meteordevelopment.meteorclient.events.world;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CollisionType
/*    */ {
/* 15 */   BLOCK,
/* 16 */   FLUID;
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\world\CollisionShapeEvent$CollisionType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */