/*    */ package meteordevelopment.meteorclient.events.world;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AmbientOcclusionEvent
/*    */ {
/*  9 */   private static final AmbientOcclusionEvent INSTANCE = new AmbientOcclusionEvent();
/*    */   
/* 11 */   public float lightLevel = -1.0F;
/*    */   
/*    */   public static AmbientOcclusionEvent get() {
/* 14 */     INSTANCE.lightLevel = -1.0F;
/* 15 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\world\AmbientOcclusionEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */