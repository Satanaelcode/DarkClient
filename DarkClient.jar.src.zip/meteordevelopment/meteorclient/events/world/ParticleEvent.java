/*    */ package meteordevelopment.meteorclient.events.world;
/*    */ 
/*    */ import meteordevelopment.meteorclient.events.Cancellable;
/*    */ import net.minecraft.class_2394;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParticleEvent
/*    */   extends Cancellable
/*    */ {
/* 12 */   private static final ParticleEvent INSTANCE = new ParticleEvent();
/*    */   
/*    */   public class_2394 particle;
/*    */   
/*    */   public static ParticleEvent get(class_2394 particle) {
/* 17 */     INSTANCE.setCancelled(false);
/* 18 */     INSTANCE.particle = particle;
/* 19 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\world\ParticleEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */