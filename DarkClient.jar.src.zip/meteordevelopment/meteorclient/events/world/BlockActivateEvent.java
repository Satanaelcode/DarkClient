/*    */ package meteordevelopment.meteorclient.events.world;
/*    */ 
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockActivateEvent
/*    */ {
/* 11 */   private static final BlockActivateEvent INSTANCE = new BlockActivateEvent();
/*    */   
/*    */   public class_2680 blockState;
/*    */   
/*    */   public static BlockActivateEvent get(class_2680 blockState) {
/* 16 */     INSTANCE.blockState = blockState;
/* 17 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\world\BlockActivateEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */