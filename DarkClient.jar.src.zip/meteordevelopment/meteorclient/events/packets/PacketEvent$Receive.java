/*    */ package meteordevelopment.meteorclient.events.packets;
/*    */ 
/*    */ import net.minecraft.class_2596;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Receive
/*    */   extends PacketEvent
/*    */ {
/* 15 */   private static final Receive INSTANCE = new Receive();
/*    */   
/*    */   public static Receive get(class_2596<?> packet) {
/* 18 */     INSTANCE.setCancelled(false);
/* 19 */     INSTANCE.packet = packet;
/* 20 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\packets\PacketEvent$Receive.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */