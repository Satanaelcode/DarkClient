/*    */ package meteordevelopment.meteorclient.events.packets;
/*    */ 
/*    */ import net.minecraft.class_2649;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InventoryEvent
/*    */ {
/* 11 */   private static final InventoryEvent INSTANCE = new InventoryEvent();
/*    */   
/*    */   public class_2649 packet;
/*    */   
/*    */   public static InventoryEvent get(class_2649 packet) {
/* 16 */     INSTANCE.packet = packet;
/* 17 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\packets\InventoryEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */