/*    */ package meteordevelopment.meteorclient.events.packets;
/*    */ 
/*    */ import meteordevelopment.meteorclient.events.Cancellable;
/*    */ import net.minecraft.class_2596;
/*    */ 
/*    */ 
/*    */ public class PacketEvent
/*    */   extends Cancellable
/*    */ {
/*    */   public class_2596<?> packet;
/*    */   
/*    */   public static class Receive
/*    */     extends PacketEvent
/*    */   {
/* 15 */     private static final Receive INSTANCE = new Receive();
/*    */     
/*    */     public static Receive get(class_2596<?> packet) {
/* 18 */       INSTANCE.setCancelled(false);
/* 19 */       INSTANCE.packet = packet;
/* 20 */       return INSTANCE;
/*    */     }
/*    */   }
/*    */   
/*    */   public static class Send extends PacketEvent {
/* 25 */     private static final Send INSTANCE = new Send();
/*    */     
/*    */     public static Send get(class_2596<?> packet) {
/* 28 */       INSTANCE.setCancelled(false);
/* 29 */       INSTANCE.packet = packet;
/* 30 */       return INSTANCE;
/*    */     }
/*    */   }
/*    */   
/*    */   public static class Sent extends PacketEvent {
/* 35 */     private static final Sent INSTANCE = new Sent();
/*    */     
/*    */     public static Sent get(class_2596<?> packet) {
/* 38 */       INSTANCE.packet = packet;
/* 39 */       return INSTANCE;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\packets\PacketEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */