/*    */ package meteordevelopment.meteorclient.events.packets;
/*    */ 
/*    */ import net.minecraft.class_2653;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContainerSlotUpdateEvent
/*    */ {
/* 11 */   private static final ContainerSlotUpdateEvent INSTANCE = new ContainerSlotUpdateEvent();
/*    */   
/*    */   public class_2653 packet;
/*    */   
/*    */   public static ContainerSlotUpdateEvent get(class_2653 packet) {
/* 16 */     INSTANCE.packet = packet;
/* 17 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\packets\ContainerSlotUpdateEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */