/*    */ package meteordevelopment.meteorclient.events.packets;
/*    */ 
/*    */ import net.minecraft.class_2767;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlaySoundPacketEvent
/*    */ {
/* 12 */   private static final PlaySoundPacketEvent INSTANCE = new PlaySoundPacketEvent();
/*    */   
/*    */   public class_2767 packet;
/*    */   
/*    */   public static PlaySoundPacketEvent get(class_2767 packet) {
/* 17 */     INSTANCE.packet = packet;
/* 18 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\packets\PlaySoundPacketEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */