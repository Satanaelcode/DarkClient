/*    */ package meteordevelopment.meteorclient.events.packets;
/*    */ 
/*    */ import net.minecraft.class_2596;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Send
/*    */   extends PacketEvent
/*    */ {
/* 25 */   private static final Send INSTANCE = new Send();
/*    */   
/*    */   public static Send get(class_2596<?> packet) {
/* 28 */     INSTANCE.setCancelled(false);
/* 29 */     INSTANCE.packet = packet;
/* 30 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\packets\PacketEvent$Send.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */