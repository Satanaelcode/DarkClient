/*    */ package meteordevelopment.meteorclient.events.packets;
/*    */ 
/*    */ import net.minecraft.class_2596;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Sent
/*    */   extends PacketEvent
/*    */ {
/* 35 */   private static final Sent INSTANCE = new Sent();
/*    */   
/*    */   public static Sent get(class_2596<?> packet) {
/* 38 */     INSTANCE.packet = packet;
/* 39 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\packets\PacketEvent$Sent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */