/*    */ package meteordevelopment.meteorclient.events.meteor;
/*    */ 
/*    */ import meteordevelopment.meteorclient.events.Cancellable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharTypedEvent
/*    */   extends Cancellable
/*    */ {
/* 11 */   private static final CharTypedEvent INSTANCE = new CharTypedEvent();
/*    */   
/*    */   public char c;
/*    */   
/*    */   public static CharTypedEvent get(char c) {
/* 16 */     INSTANCE.setCancelled(false);
/* 17 */     INSTANCE.c = c;
/* 18 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\meteor\CharTypedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */