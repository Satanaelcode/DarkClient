/*    */ package meteordevelopment.meteorclient.events.meteor;
/*    */ 
/*    */ import meteordevelopment.meteorclient.events.Cancellable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MouseScrollEvent
/*    */   extends Cancellable
/*    */ {
/* 11 */   private static final MouseScrollEvent INSTANCE = new MouseScrollEvent();
/*    */   
/*    */   public double value;
/*    */   
/*    */   public static MouseScrollEvent get(double value) {
/* 16 */     INSTANCE.setCancelled(false);
/* 17 */     INSTANCE.value = value;
/*    */     
/* 19 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\meteor\MouseScrollEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */