/*    */ package meteordevelopment.meteorclient.events.meteor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CustomFontChangedEvent
/*    */ {
/* 10 */   private static final CustomFontChangedEvent INSTANCE = new CustomFontChangedEvent();
/*    */   
/*    */   public static CustomFontChangedEvent get() {
/* 13 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\meteor\CustomFontChangedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */