/*    */ package meteordevelopment.meteorclient.events.meteor;
/*    */ 
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModuleBindChangedEvent
/*    */ {
/* 11 */   private static final ModuleBindChangedEvent INSTANCE = new ModuleBindChangedEvent();
/*    */   
/*    */   public Module module;
/*    */   
/*    */   public static ModuleBindChangedEvent get(Module module) {
/* 16 */     INSTANCE.module = module;
/* 17 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\meteor\ModuleBindChangedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */