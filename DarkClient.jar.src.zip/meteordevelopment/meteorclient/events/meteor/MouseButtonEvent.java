/*    */ package meteordevelopment.meteorclient.events.meteor;
/*    */ 
/*    */ import meteordevelopment.meteorclient.events.Cancellable;
/*    */ import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MouseButtonEvent
/*    */   extends Cancellable
/*    */ {
/* 12 */   private static final MouseButtonEvent INSTANCE = new MouseButtonEvent();
/*    */   
/*    */   public int button;
/*    */   public KeyAction action;
/*    */   
/*    */   public static MouseButtonEvent get(int button, KeyAction action) {
/* 18 */     INSTANCE.setCancelled(false);
/* 19 */     INSTANCE.button = button;
/* 20 */     INSTANCE.action = action;
/* 21 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\meteor\MouseButtonEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */