/*    */ package meteordevelopment.meteorclient.events.meteor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActiveModulesChangedEvent
/*    */ {
/*  9 */   private static final ActiveModulesChangedEvent INSTANCE = new ActiveModulesChangedEvent();
/*    */   
/*    */   public static ActiveModulesChangedEvent get() {
/* 12 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\meteor\ActiveModulesChangedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */