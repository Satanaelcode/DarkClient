/*    */ package meteordevelopment.meteorclient.events.meteor;
/*    */ 
/*    */ import meteordevelopment.meteorclient.events.Cancellable;
/*    */ import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyEvent
/*    */   extends Cancellable
/*    */ {
/* 12 */   private static final KeyEvent INSTANCE = new KeyEvent();
/*    */   public int key;
/*    */   public int modifiers;
/*    */   public KeyAction action;
/*    */   
/*    */   public static KeyEvent get(int key, int modifiers, KeyAction action) {
/* 18 */     INSTANCE.setCancelled(false);
/* 19 */     INSTANCE.key = key;
/* 20 */     INSTANCE.modifiers = modifiers;
/* 21 */     INSTANCE.action = action;
/* 22 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\meteor\KeyEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */