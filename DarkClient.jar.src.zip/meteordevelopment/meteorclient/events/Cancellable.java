/*    */ package meteordevelopment.meteorclient.events;
/*    */ 
/*    */ import meteordevelopment.orbit.ICancellable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Cancellable
/*    */   implements ICancellable
/*    */ {
/*    */   private boolean cancelled = false;
/*    */   
/*    */   public void setCancelled(boolean cancelled) {
/* 15 */     this.cancelled = cancelled;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isCancelled() {
/* 20 */     return this.cancelled;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\Cancellable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */