/*    */ package meteordevelopment.meteorclient.events.render;
/*    */ 
/*    */ import meteordevelopment.meteorclient.utils.Utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Render2DEvent
/*    */ {
/* 11 */   private static final Render2DEvent INSTANCE = new Render2DEvent();
/*    */   public int screenWidth;
/*    */   public int screenHeight;
/*    */   public double frameTime;
/*    */   public float tickDelta;
/*    */   
/*    */   public static Render2DEvent get(int screenWidth, int screenHeight, float tickDelta) {
/* 18 */     INSTANCE.screenWidth = screenWidth;
/* 19 */     INSTANCE.screenHeight = screenHeight;
/* 20 */     INSTANCE.frameTime = Utils.frameTime;
/* 21 */     INSTANCE.tickDelta = tickDelta;
/* 22 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\render\Render2DEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */