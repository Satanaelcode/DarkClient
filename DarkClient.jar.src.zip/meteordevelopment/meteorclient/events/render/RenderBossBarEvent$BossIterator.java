/*    */ package meteordevelopment.meteorclient.events.render;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import net.minecraft.class_345;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BossIterator
/*    */ {
/* 40 */   private static final BossIterator INSTANCE = new BossIterator();
/*    */   
/*    */   public Iterator<class_345> iterator;
/*    */   
/*    */   public static BossIterator get(Iterator<class_345> iterator) {
/* 45 */     INSTANCE.iterator = iterator;
/* 46 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\render\RenderBossBarEvent$BossIterator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */