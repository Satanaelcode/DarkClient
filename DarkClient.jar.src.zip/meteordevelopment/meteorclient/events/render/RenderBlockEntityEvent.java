/*    */ package meteordevelopment.meteorclient.events.render;
/*    */ 
/*    */ import meteordevelopment.meteorclient.events.Cancellable;
/*    */ import net.minecraft.class_2586;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderBlockEntityEvent
/*    */   extends Cancellable
/*    */ {
/* 12 */   private static final RenderBlockEntityEvent INSTANCE = new RenderBlockEntityEvent();
/*    */   
/*    */   public class_2586 blockEntity;
/*    */   
/*    */   public static RenderBlockEntityEvent get(class_2586 blockEntity) {
/* 17 */     INSTANCE.setCancelled(false);
/* 18 */     INSTANCE.blockEntity = blockEntity;
/* 19 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\render\RenderBlockEntityEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */