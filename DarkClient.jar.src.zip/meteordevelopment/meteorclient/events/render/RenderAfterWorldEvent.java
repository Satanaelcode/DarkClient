/*    */ package meteordevelopment.meteorclient.events.render;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderAfterWorldEvent
/*    */ {
/*  9 */   private static final RenderAfterWorldEvent INSTANCE = new RenderAfterWorldEvent();
/*    */   
/*    */   public static RenderAfterWorldEvent get() {
/* 12 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\render\RenderAfterWorldEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */