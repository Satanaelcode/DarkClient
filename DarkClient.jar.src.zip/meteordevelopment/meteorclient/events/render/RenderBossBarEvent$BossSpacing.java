/*    */ package meteordevelopment.meteorclient.events.render;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BossSpacing
/*    */ {
/* 29 */   private static final BossSpacing INSTANCE = new BossSpacing();
/*    */   
/*    */   public int spacing;
/*    */   
/*    */   public static BossSpacing get(int spacing) {
/* 34 */     INSTANCE.spacing = spacing;
/* 35 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\render\RenderBossBarEvent$BossSpacing.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */