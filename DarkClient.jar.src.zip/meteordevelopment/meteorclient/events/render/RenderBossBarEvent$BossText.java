/*    */ package meteordevelopment.meteorclient.events.render;
/*    */ 
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_345;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BossText
/*    */ {
/* 16 */   private static final BossText INSTANCE = new BossText();
/*    */   
/*    */   public class_345 bossBar;
/*    */   public class_2561 name;
/*    */   
/*    */   public static BossText get(class_345 bossBar, class_2561 name) {
/* 22 */     INSTANCE.bossBar = bossBar;
/* 23 */     INSTANCE.name = name;
/* 24 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\render\RenderBossBarEvent$BossText.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */