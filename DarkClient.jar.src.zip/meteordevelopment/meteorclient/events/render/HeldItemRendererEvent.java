/*    */ package meteordevelopment.meteorclient.events.render;
/*    */ 
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HeldItemRendererEvent
/*    */ {
/* 12 */   private static final HeldItemRendererEvent INSTANCE = new HeldItemRendererEvent();
/*    */   
/*    */   public class_1268 hand;
/*    */   public class_4587 matrix;
/*    */   
/*    */   public static HeldItemRendererEvent get(class_1268 hand, class_4587 matrices) {
/* 18 */     INSTANCE.hand = hand;
/* 19 */     INSTANCE.matrix = matrices;
/* 20 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\render\HeldItemRendererEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */