/*    */ package meteordevelopment.meteorclient.events.render;
/*    */ 
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_5632;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TooltipDataEvent
/*    */ {
/* 13 */   private static final TooltipDataEvent INSTANCE = new TooltipDataEvent();
/*    */   
/*    */   public class_5632 tooltipData;
/*    */   public class_1799 itemStack;
/*    */   
/*    */   public static TooltipDataEvent get(class_1799 itemStack) {
/* 19 */     INSTANCE.tooltipData = null;
/* 20 */     INSTANCE.itemStack = itemStack;
/* 21 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\render\TooltipDataEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */