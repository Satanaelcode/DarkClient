/*    */ package meteordevelopment.meteorclient.events.render;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GetFovEvent
/*    */ {
/*  9 */   private static final GetFovEvent INSTANCE = new GetFovEvent();
/*    */   
/*    */   public double fov;
/*    */   
/*    */   public static GetFovEvent get(double fov) {
/* 14 */     INSTANCE.fov = fov;
/* 15 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\render\GetFovEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */