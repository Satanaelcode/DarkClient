/*    */ package meteordevelopment.meteorclient.events.render;
/*    */ 
/*    */ import meteordevelopment.meteorclient.renderer.Renderer3D;
/*    */ import meteordevelopment.meteorclient.utils.Utils;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Render3DEvent
/*    */ {
/* 13 */   private static final Render3DEvent INSTANCE = new Render3DEvent();
/*    */   
/*    */   public class_4587 matrices;
/*    */   
/*    */   public Renderer3D renderer;
/*    */   
/*    */   public double frameTime;
/*    */   
/*    */   public static Render3DEvent get(class_4587 matrices, Renderer3D renderer, float tickDelta, double offsetX, double offsetY, double offsetZ) {
/* 22 */     INSTANCE.matrices = matrices;
/* 23 */     INSTANCE.renderer = renderer;
/* 24 */     INSTANCE.frameTime = Utils.frameTime;
/* 25 */     INSTANCE.tickDelta = tickDelta;
/* 26 */     INSTANCE.offsetX = offsetX;
/* 27 */     INSTANCE.offsetY = offsetY;
/* 28 */     INSTANCE.offsetZ = offsetZ;
/* 29 */     return INSTANCE;
/*    */   }
/*    */   
/*    */   public float tickDelta;
/*    */   public double offsetX;
/*    */   public double offsetY;
/*    */   public double offsetZ;
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\render\Render3DEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */