/*    */ package meteordevelopment.meteorclient.events.render;
/*    */ 
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArmRenderEvent
/*    */ {
/* 13 */   public static ArmRenderEvent INSTANCE = new ArmRenderEvent();
/*    */   
/*    */   public class_4587 matrix;
/*    */   public class_1268 hand;
/*    */   
/*    */   public static ArmRenderEvent get(class_1268 hand, class_4587 matrices) {
/* 19 */     INSTANCE.matrix = matrices;
/* 20 */     INSTANCE.hand = hand;
/*    */     
/* 22 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\render\ArmRenderEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */