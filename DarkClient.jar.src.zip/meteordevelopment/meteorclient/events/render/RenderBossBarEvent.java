/*    */ package meteordevelopment.meteorclient.events.render;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import meteordevelopment.meteorclient.events.Cancellable;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_345;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderBossBarEvent
/*    */   extends Cancellable
/*    */ {
/*    */   public static class BossText
/*    */   {
/* 16 */     private static final BossText INSTANCE = new BossText();
/*    */     
/*    */     public class_345 bossBar;
/*    */     public class_2561 name;
/*    */     
/*    */     public static BossText get(class_345 bossBar, class_2561 name) {
/* 22 */       INSTANCE.bossBar = bossBar;
/* 23 */       INSTANCE.name = name;
/* 24 */       return INSTANCE;
/*    */     }
/*    */   }
/*    */   
/*    */   public static class BossSpacing {
/* 29 */     private static final BossSpacing INSTANCE = new BossSpacing();
/*    */     
/*    */     public int spacing;
/*    */     
/*    */     public static BossSpacing get(int spacing) {
/* 34 */       INSTANCE.spacing = spacing;
/* 35 */       return INSTANCE;
/*    */     }
/*    */   }
/*    */   
/*    */   public static class BossIterator {
/* 40 */     private static final BossIterator INSTANCE = new BossIterator();
/*    */     
/*    */     public Iterator<class_345> iterator;
/*    */     
/*    */     public static BossIterator get(Iterator<class_345> iterator) {
/* 45 */       INSTANCE.iterator = iterator;
/* 46 */       return INSTANCE;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\render\RenderBossBarEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */