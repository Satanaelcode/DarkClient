/*    */ package meteordevelopment.meteorclient.events.entity;
/*    */ 
/*    */ import net.minecraft.class_1297;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityDestroyEvent
/*    */ {
/* 11 */   private static final EntityDestroyEvent INSTANCE = new EntityDestroyEvent();
/*    */   
/*    */   public class_1297 entity;
/*    */   
/*    */   public static EntityDestroyEvent get(class_1297 entity) {
/* 16 */     INSTANCE.entity = entity;
/* 17 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\EntityDestroyEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */