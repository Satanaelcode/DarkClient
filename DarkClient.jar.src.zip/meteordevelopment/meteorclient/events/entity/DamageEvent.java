/*    */ package meteordevelopment.meteorclient.events.entity;
/*    */ 
/*    */ import net.minecraft.class_1282;
/*    */ import net.minecraft.class_1309;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DamageEvent
/*    */ {
/* 12 */   private static final DamageEvent INSTANCE = new DamageEvent();
/*    */   
/*    */   public class_1309 entity;
/*    */   public class_1282 source;
/*    */   
/*    */   public static DamageEvent get(class_1309 entity, class_1282 source) {
/* 18 */     INSTANCE.entity = entity;
/* 19 */     INSTANCE.source = source;
/* 20 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\DamageEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */