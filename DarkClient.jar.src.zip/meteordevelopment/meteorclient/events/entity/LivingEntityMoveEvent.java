/*    */ package meteordevelopment.meteorclient.events.entity;
/*    */ 
/*    */ import net.minecraft.class_1309;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LivingEntityMoveEvent
/*    */ {
/* 12 */   private static final LivingEntityMoveEvent INSTANCE = new LivingEntityMoveEvent();
/*    */   
/*    */   public class_1309 entity;
/*    */   public class_243 movement;
/*    */   
/*    */   public static LivingEntityMoveEvent get(class_1309 entity, class_243 movement) {
/* 18 */     INSTANCE.entity = entity;
/* 19 */     INSTANCE.movement = movement;
/* 20 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\LivingEntityMoveEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */