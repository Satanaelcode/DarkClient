/*    */ package meteordevelopment.meteorclient.events.entity;
/*    */ 
/*    */ import net.minecraft.class_1690;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BoatMoveEvent
/*    */ {
/* 11 */   private static final BoatMoveEvent INSTANCE = new BoatMoveEvent();
/*    */   
/*    */   public class_1690 boat;
/*    */   
/*    */   public static BoatMoveEvent get(class_1690 entity) {
/* 16 */     INSTANCE.boat = entity;
/* 17 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\BoatMoveEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */