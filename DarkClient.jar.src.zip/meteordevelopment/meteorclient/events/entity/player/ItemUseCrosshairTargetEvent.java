/*    */ package meteordevelopment.meteorclient.events.entity.player;
/*    */ 
/*    */ import net.minecraft.class_239;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemUseCrosshairTargetEvent
/*    */ {
/* 11 */   private static final ItemUseCrosshairTargetEvent INSTANCE = new ItemUseCrosshairTargetEvent();
/*    */   
/*    */   public class_239 target;
/*    */   
/*    */   public static ItemUseCrosshairTargetEvent get(class_239 target) {
/* 16 */     INSTANCE.target = target;
/* 17 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\player\ItemUseCrosshairTargetEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */