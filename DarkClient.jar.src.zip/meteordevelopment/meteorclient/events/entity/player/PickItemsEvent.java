/*    */ package meteordevelopment.meteorclient.events.entity.player;
/*    */ 
/*    */ import net.minecraft.class_1799;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PickItemsEvent
/*    */ {
/* 11 */   private static final PickItemsEvent INSTANCE = new PickItemsEvent();
/*    */   
/*    */   public class_1799 itemStack;
/*    */   public int count;
/*    */   
/*    */   public static PickItemsEvent get(class_1799 itemStack, int count) {
/* 17 */     INSTANCE.itemStack = itemStack;
/* 18 */     INSTANCE.count = count;
/* 19 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\player\PickItemsEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */