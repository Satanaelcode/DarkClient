/*    */ package meteordevelopment.meteorclient.events.entity.player;
/*    */ 
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_1269;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InteractItemEvent
/*    */ {
/* 12 */   private static final InteractItemEvent INSTANCE = new InteractItemEvent();
/*    */   
/*    */   public class_1268 hand;
/*    */   public class_1269 toReturn;
/*    */   
/*    */   public static InteractItemEvent get(class_1268 hand) {
/* 18 */     INSTANCE.hand = hand;
/* 19 */     INSTANCE.toReturn = null;
/*    */     
/* 21 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\player\InteractItemEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */