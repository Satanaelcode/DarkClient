/*    */ package meteordevelopment.meteorclient.events.entity.player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClipAtLedgeEvent
/*    */ {
/*  9 */   private static final ClipAtLedgeEvent INSTANCE = new ClipAtLedgeEvent();
/*    */   private boolean set;
/*    */   private boolean clip;
/*    */   
/*    */   public void reset() {
/* 14 */     this.set = false;
/*    */   }
/*    */   
/*    */   public void setClip(boolean clip) {
/* 18 */     this.set = true;
/* 19 */     this.clip = clip;
/*    */   }
/*    */   
/*    */   public boolean isSet() {
/* 23 */     return this.set;
/*    */   }
/*    */   public boolean isClip() {
/* 26 */     return this.clip;
/*    */   }
/*    */   
/*    */   public static ClipAtLedgeEvent get() {
/* 30 */     INSTANCE.reset();
/* 31 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\player\ClipAtLedgeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */