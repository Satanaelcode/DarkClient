/*    */ package meteordevelopment.meteorclient.events.entity.player;
/*    */ 
/*    */ import net.minecraft.class_1313;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerMoveEvent
/*    */ {
/* 12 */   private static final PlayerMoveEvent INSTANCE = new PlayerMoveEvent();
/*    */   
/*    */   public class_1313 type;
/*    */   public class_243 movement;
/*    */   
/*    */   public static PlayerMoveEvent get(class_1313 type, class_243 movement) {
/* 18 */     INSTANCE.type = type;
/* 19 */     INSTANCE.movement = movement;
/* 20 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\player\PlayerMoveEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */