/*    */ package meteordevelopment.meteorclient.events.entity.player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockBreakingCooldownEvent
/*    */ {
/*  9 */   private static final BlockBreakingCooldownEvent INSTANCE = new BlockBreakingCooldownEvent();
/*    */   
/*    */   public int cooldown;
/*    */   
/*    */   public static BlockBreakingCooldownEvent get(int cooldown) {
/* 14 */     INSTANCE.cooldown = cooldown;
/* 15 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\player\BlockBreakingCooldownEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */