/*    */ package meteordevelopment.meteorclient.events.entity.player;
/*    */ 
/*    */ import net.minecraft.class_3610;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CanWalkOnFluidEvent
/*    */ {
/* 11 */   private static final CanWalkOnFluidEvent INSTANCE = new CanWalkOnFluidEvent();
/*    */   
/*    */   public class_3610 fluidState;
/*    */   public boolean walkOnFluid;
/*    */   
/*    */   public static CanWalkOnFluidEvent get(class_3610 fluid) {
/* 17 */     INSTANCE.fluidState = fluid;
/* 18 */     INSTANCE.walkOnFluid = false;
/* 19 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\player\CanWalkOnFluidEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */