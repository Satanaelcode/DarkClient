/*    */ package meteordevelopment.meteorclient.events.entity.player;
/*    */ 
/*    */ import meteordevelopment.meteorclient.events.Cancellable;
/*    */ import net.minecraft.class_1297;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttackEntityEvent
/*    */   extends Cancellable
/*    */ {
/* 13 */   private static final AttackEntityEvent INSTANCE = new AttackEntityEvent();
/*    */   
/*    */   public class_1297 entity;
/*    */   
/*    */   public static AttackEntityEvent get(class_1297 entity) {
/* 18 */     INSTANCE.setCancelled(false);
/* 19 */     INSTANCE.entity = entity;
/* 20 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\player\AttackEntityEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */