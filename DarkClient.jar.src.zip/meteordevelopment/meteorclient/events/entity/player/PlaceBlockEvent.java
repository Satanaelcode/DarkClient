/*    */ package meteordevelopment.meteorclient.events.entity.player;
/*    */ 
/*    */ import net.minecraft.class_2248;
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlaceBlockEvent
/*    */ {
/* 12 */   private static final PlaceBlockEvent INSTANCE = new PlaceBlockEvent();
/*    */   
/*    */   public class_2338 blockPos;
/*    */   public class_2248 block;
/*    */   
/*    */   public static PlaceBlockEvent get(class_2338 blockPos, class_2248 block) {
/* 18 */     INSTANCE.blockPos = blockPos;
/* 19 */     INSTANCE.block = block;
/* 20 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\player\PlaceBlockEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */