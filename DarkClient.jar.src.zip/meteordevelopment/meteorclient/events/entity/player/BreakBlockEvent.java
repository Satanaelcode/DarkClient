/*    */ package meteordevelopment.meteorclient.events.entity.player;
/*    */ 
/*    */ import meteordevelopment.meteorclient.events.Cancellable;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BreakBlockEvent
/*    */   extends Cancellable
/*    */ {
/* 14 */   private static final BreakBlockEvent INSTANCE = new BreakBlockEvent();
/*    */   
/*    */   public class_2338 blockPos;
/*    */   
/*    */   public class_2680 getBlockState(class_1937 world) {
/* 19 */     return world.method_8320(this.blockPos);
/*    */   }
/*    */   
/*    */   public static BreakBlockEvent get(class_2338 blockPos) {
/* 23 */     INSTANCE.blockPos = blockPos;
/* 24 */     INSTANCE.setCancelled(false);
/* 25 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\player\BreakBlockEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */