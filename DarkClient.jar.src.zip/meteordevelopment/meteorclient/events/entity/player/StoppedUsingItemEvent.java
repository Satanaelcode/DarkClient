/*    */ package meteordevelopment.meteorclient.events.entity.player;
/*    */ 
/*    */ import net.minecraft.class_1799;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StoppedUsingItemEvent
/*    */ {
/* 11 */   private static final StoppedUsingItemEvent INSTANCE = new StoppedUsingItemEvent();
/*    */   
/*    */   public class_1799 itemStack;
/*    */   
/*    */   public static StoppedUsingItemEvent get(class_1799 itemStack) {
/* 16 */     INSTANCE.itemStack = itemStack;
/* 17 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\player\StoppedUsingItemEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */