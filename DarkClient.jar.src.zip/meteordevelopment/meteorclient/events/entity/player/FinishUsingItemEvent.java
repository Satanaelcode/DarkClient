/*    */ package meteordevelopment.meteorclient.events.entity.player;
/*    */ 
/*    */ import net.minecraft.class_1799;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FinishUsingItemEvent
/*    */ {
/* 11 */   private static final FinishUsingItemEvent INSTANCE = new FinishUsingItemEvent();
/*    */   
/*    */   public class_1799 itemStack;
/*    */   
/*    */   public static FinishUsingItemEvent get(class_1799 itemStack) {
/* 16 */     INSTANCE.itemStack = itemStack;
/* 17 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\player\FinishUsingItemEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */