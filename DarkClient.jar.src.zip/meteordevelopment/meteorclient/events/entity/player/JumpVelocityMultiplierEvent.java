/*    */ package meteordevelopment.meteorclient.events.entity.player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JumpVelocityMultiplierEvent
/*    */ {
/*  9 */   private static final JumpVelocityMultiplierEvent INSTANCE = new JumpVelocityMultiplierEvent();
/*    */   
/* 11 */   public float multiplier = 1.0F;
/*    */   
/*    */   public static JumpVelocityMultiplierEvent get() {
/* 14 */     INSTANCE.multiplier = 1.0F;
/* 15 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\player\JumpVelocityMultiplierEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */