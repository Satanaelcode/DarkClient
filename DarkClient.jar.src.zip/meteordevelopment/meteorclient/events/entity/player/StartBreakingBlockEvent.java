/*    */ package meteordevelopment.meteorclient.events.entity.player;
/*    */ 
/*    */ import meteordevelopment.meteorclient.events.Cancellable;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2350;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StartBreakingBlockEvent
/*    */   extends Cancellable
/*    */ {
/* 13 */   private static final StartBreakingBlockEvent INSTANCE = new StartBreakingBlockEvent();
/*    */   
/*    */   public class_2338 blockPos;
/*    */   public class_2350 direction;
/*    */   
/*    */   public static StartBreakingBlockEvent get(class_2338 blockPos, class_2350 direction) {
/* 19 */     INSTANCE.setCancelled(false);
/* 20 */     INSTANCE.blockPos = blockPos;
/* 21 */     INSTANCE.direction = direction;
/* 22 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\player\StartBreakingBlockEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */