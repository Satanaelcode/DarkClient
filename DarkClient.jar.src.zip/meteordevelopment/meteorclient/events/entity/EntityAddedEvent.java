/*    */ package meteordevelopment.meteorclient.events.entity;
/*    */ 
/*    */ import net.minecraft.class_1297;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityAddedEvent
/*    */ {
/* 11 */   private static final EntityAddedEvent INSTANCE = new EntityAddedEvent();
/*    */   
/*    */   public class_1297 entity;
/*    */   
/*    */   public static EntityAddedEvent get(class_1297 entity) {
/* 16 */     INSTANCE.entity = entity;
/* 17 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\entity\EntityAddedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */