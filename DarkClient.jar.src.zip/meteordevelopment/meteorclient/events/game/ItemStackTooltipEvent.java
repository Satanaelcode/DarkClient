/*    */ package meteordevelopment.meteorclient.events.game;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_2561;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemStackTooltipEvent
/*    */ {
/* 14 */   private static final ItemStackTooltipEvent INSTANCE = new ItemStackTooltipEvent();
/*    */   
/*    */   public class_1799 itemStack;
/*    */   public List<class_2561> list;
/*    */   
/*    */   public static ItemStackTooltipEvent get(class_1799 itemStack, List<class_2561> list) {
/* 20 */     INSTANCE.itemStack = itemStack;
/* 21 */     INSTANCE.list = list;
/* 22 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\game\ItemStackTooltipEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */