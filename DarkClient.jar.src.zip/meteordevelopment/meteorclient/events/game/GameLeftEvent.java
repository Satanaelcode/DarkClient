/*    */ package meteordevelopment.meteorclient.events.game;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GameLeftEvent
/*    */ {
/*  9 */   private static final GameLeftEvent INSTANCE = new GameLeftEvent();
/*    */   
/*    */   public static GameLeftEvent get() {
/* 12 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\game\GameLeftEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */