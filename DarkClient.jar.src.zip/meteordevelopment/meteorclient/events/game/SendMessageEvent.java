/*    */ package meteordevelopment.meteorclient.events.game;
/*    */ 
/*    */ import meteordevelopment.meteorclient.events.Cancellable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SendMessageEvent
/*    */   extends Cancellable
/*    */ {
/* 11 */   private static final SendMessageEvent INSTANCE = new SendMessageEvent();
/*    */   
/*    */   public String message;
/*    */   
/*    */   public static SendMessageEvent get(String message) {
/* 16 */     INSTANCE.setCancelled(false);
/* 17 */     INSTANCE.message = message;
/* 18 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\game\SendMessageEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */