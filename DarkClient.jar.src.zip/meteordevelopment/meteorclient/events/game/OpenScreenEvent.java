/*    */ package meteordevelopment.meteorclient.events.game;
/*    */ 
/*    */ import meteordevelopment.meteorclient.events.Cancellable;
/*    */ import net.minecraft.class_437;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpenScreenEvent
/*    */   extends Cancellable
/*    */ {
/* 12 */   private static final OpenScreenEvent INSTANCE = new OpenScreenEvent();
/*    */   
/*    */   public class_437 screen;
/*    */   
/*    */   public static OpenScreenEvent get(class_437 screen) {
/* 17 */     INSTANCE.setCancelled(false);
/* 18 */     INSTANCE.screen = screen;
/* 19 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\game\OpenScreenEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */