/*    */ package meteordevelopment.meteorclient.events.game;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourcePacksReloadedEvent
/*    */ {
/*  9 */   private static final ResourcePacksReloadedEvent INSTANCE = new ResourcePacksReloadedEvent();
/*    */   
/*    */   public static ResourcePacksReloadedEvent get() {
/* 12 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\game\ResourcePacksReloadedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */