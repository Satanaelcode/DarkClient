/*    */ package meteordevelopment.meteorclient.events.game;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WindowResizedEvent
/*    */ {
/*  9 */   private static final WindowResizedEvent INSTANCE = new WindowResizedEvent();
/*    */   
/*    */   public static WindowResizedEvent get() {
/* 12 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\game\WindowResizedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */