/*    */ package meteordevelopment.meteorclient.events.game;
/*    */ 
/*    */ import net.minecraft.class_1799;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SectionVisibleEvent
/*    */ {
/* 11 */   private static final SectionVisibleEvent INSTANCE = new SectionVisibleEvent();
/*    */   
/*    */   public class_1799.class_5422 section;
/*    */   public boolean visible;
/*    */   
/*    */   public static SectionVisibleEvent get(class_1799.class_5422 section, boolean visible) {
/* 17 */     INSTANCE.section = section;
/* 18 */     INSTANCE.visible = visible;
/* 19 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\game\SectionVisibleEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */