/*    */ package meteordevelopment.meteorclient.events.game;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GameJoinedEvent
/*    */ {
/*  9 */   private static final GameJoinedEvent INSTANCE = new GameJoinedEvent();
/*    */   
/*    */   public static GameJoinedEvent get() {
/* 12 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\game\GameJoinedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */