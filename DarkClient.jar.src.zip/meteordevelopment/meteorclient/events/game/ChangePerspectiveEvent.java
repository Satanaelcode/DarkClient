/*    */ package meteordevelopment.meteorclient.events.game;
/*    */ 
/*    */ import meteordevelopment.meteorclient.events.Cancellable;
/*    */ import net.minecraft.class_5498;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChangePerspectiveEvent
/*    */   extends Cancellable
/*    */ {
/* 12 */   private static final ChangePerspectiveEvent INSTANCE = new ChangePerspectiveEvent();
/*    */   
/*    */   public class_5498 perspective;
/*    */   
/*    */   public static ChangePerspectiveEvent get(class_5498 perspective) {
/* 17 */     INSTANCE.setCancelled(false);
/* 18 */     INSTANCE.perspective = perspective;
/* 19 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\meteorclient\events\game\ChangePerspectiveEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */