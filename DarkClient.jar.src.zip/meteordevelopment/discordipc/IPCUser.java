package meteordevelopment.discordipc;

public class IPCUser {
  public String id;
  
  public String username;
  
  public String discriminator;
  
  public String avatar;
  
  public boolean bot;
  
  public String flags;
  
  public int premium_type;
}


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\discordipc\IPCUser.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */