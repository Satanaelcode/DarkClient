package meteordevelopment.discordipc;

public class Timestamps {
  public Long start;
  
  public Long end;
}


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\discordipc\RichPresence$Timestamps.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */