/*   */ package meteordevelopment.discordipc;
/*   */ public final class Packet extends Record { private final Opcode opcode;
/*   */   private final JsonObject data;
/*   */   
/* 5 */   public Packet(Opcode opcode, JsonObject data) { this.opcode = opcode; this.data = data; } public final String toString() { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: <illegal opcode> toString : (Lmeteordevelopment/discordipc/Packet;)Ljava/lang/String;
/*   */     //   6: areturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #5	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/* 5 */     //   0	7	0	this	Lmeteordevelopment/discordipc/Packet; } public Opcode opcode() { return this.opcode; } public final int hashCode() { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: <illegal opcode> hashCode : (Lmeteordevelopment/discordipc/Packet;)I
/*   */     //   6: ireturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #5	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/*   */     //   0	7	0	this	Lmeteordevelopment/discordipc/Packet; } public final boolean equals(Object o) { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: aload_1
/*   */     //   2: <illegal opcode> equals : (Lmeteordevelopment/discordipc/Packet;Ljava/lang/Object;)Z
/*   */     //   7: ireturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #5	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/*   */     //   0	8	0	this	Lmeteordevelopment/discordipc/Packet;
/* 5 */     //   0	8	1	o	Ljava/lang/Object; } public JsonObject data() { return this.data; }
/*   */    }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\discordipc\Packet.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */