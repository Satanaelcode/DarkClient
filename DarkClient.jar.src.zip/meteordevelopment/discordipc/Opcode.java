/*    */ package meteordevelopment.discordipc;
/*    */ 
/*    */ public enum Opcode {
/*  4 */   Handshake,
/*  5 */   Frame,
/*  6 */   Close,
/*  7 */   Ping,
/*  8 */   Pong;
/*    */   static {
/* 10 */     VALUES = values();
/*    */   }
/*    */   
/*    */   private static final Opcode[] VALUES;
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\discordipc\Opcode.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */