package meteordevelopment.discordipc;

public class Assets {
  public String large_image;
  
  public String large_text;
  
  public String small_image;
  
  public String small_text;
}


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\discordipc\RichPresence$Assets.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */