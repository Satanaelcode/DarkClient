/*     */ package meteordevelopment.discordipc;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.util.function.BiConsumer;
/*     */ import meteordevelopment.discordipc.connection.Connection;
/*     */ 
/*     */ public class DiscordIPC {
/*  11 */   private static final Gson GSON = new Gson();
/*     */   
/*  13 */   private static BiConsumer<Integer, String> onError = DiscordIPC::defaultErrorCallback;
/*     */   
/*     */   private static Connection c;
/*     */   
/*     */   private static Runnable onReady;
/*     */   
/*     */   private static boolean receivedDispatch;
/*     */   
/*     */   private static JsonObject queuedActivity;
/*     */   private static IPCUser user;
/*     */   
/*     */   public static void setOnError(BiConsumer<Integer, String> onError) {
/*  25 */     DiscordIPC.onError = onError;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean start(long appId, Runnable onReady) {
/*  36 */     c = Connection.open(DiscordIPC::onPacket);
/*  37 */     if (c == null) return false;
/*     */     
/*  39 */     DiscordIPC.onReady = onReady;
/*     */ 
/*     */     
/*  42 */     JsonObject o = new JsonObject();
/*  43 */     o.addProperty("v", Integer.valueOf(1));
/*  44 */     o.addProperty("client_id", Long.toString(appId));
/*  45 */     c.write(Opcode.Handshake, o);
/*     */     
/*  47 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isConnected() {
/*  54 */     return (c != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IPCUser getUser() {
/*  61 */     return user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setActivity(RichPresence presence) {
/*  69 */     if (c == null)
/*     */       return; 
/*  71 */     queuedActivity = presence.toJson();
/*  72 */     if (receivedDispatch) sendActivity();
/*     */   
/*     */   }
/*     */   
/*     */   public static void stop() {
/*  77 */     if (c != null) {
/*  78 */       c.close();
/*     */       
/*  80 */       c = null;
/*  81 */       onReady = null;
/*  82 */       receivedDispatch = false;
/*  83 */       queuedActivity = null;
/*  84 */       user = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void sendActivity() {
/*  89 */     JsonObject args = new JsonObject();
/*  90 */     args.addProperty("pid", Integer.valueOf(getPID()));
/*  91 */     args.add("activity", (JsonElement)queuedActivity);
/*     */     
/*  93 */     JsonObject o = new JsonObject();
/*  94 */     o.addProperty("cmd", "SET_ACTIVITY");
/*  95 */     o.add("args", (JsonElement)args);
/*     */     
/*  97 */     c.write(Opcode.Frame, o);
/*  98 */     queuedActivity = null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void onPacket(Packet packet) {
/* 103 */     if (packet.opcode() == Opcode.Close) {
/* 104 */       if (onError != null) onError.accept(Integer.valueOf(packet.data().get("code").getAsInt()), packet.data().get("message").getAsString()); 
/* 105 */       stop();
/*     */     
/*     */     }
/* 108 */     else if (packet.opcode() == Opcode.Frame) {
/*     */       
/* 110 */       if (packet.data().has("evt") && packet.data().get("evt").getAsString().equals("ERROR")) {
/* 111 */         JsonObject d = packet.data().getAsJsonObject("data");
/* 112 */         if (onError != null) onError.accept(Integer.valueOf(d.get("code").getAsInt()), d.get("message").getAsString());
/*     */       
/*     */       }
/* 115 */       else if (packet.data().has("cmd") && packet.data().get("cmd").getAsString().equals("DISPATCH")) {
/* 116 */         receivedDispatch = true;
/* 117 */         user = (IPCUser)GSON.fromJson((JsonElement)packet.data().getAsJsonObject("data").getAsJsonObject("user"), IPCUser.class);
/*     */         
/* 119 */         if (onReady != null) onReady.run(); 
/* 120 */         if (queuedActivity != null) sendActivity(); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int getPID() {
/* 126 */     String pr = ManagementFactory.getRuntimeMXBean().getName();
/* 127 */     return Integer.parseInt(pr.substring(0, pr.indexOf('@')));
/*     */   }
/*     */   
/*     */   private static void defaultErrorCallback(int code, String message) {
/* 131 */     System.err.println("Discord IPC error " + code + " with message: " + message);
/*     */   }
/*     */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\discordipc\DiscordIPC.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */