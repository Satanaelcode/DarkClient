/*    */ package meteordevelopment.discordipc.connection;
/*    */ 
/*    */ import com.google.gson.JsonParser;
/*    */ import java.io.IOException;
/*    */ import java.io.RandomAccessFile;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.charset.Charset;
/*    */ import java.util.function.Consumer;
/*    */ import meteordevelopment.discordipc.Opcode;
/*    */ import meteordevelopment.discordipc.Packet;
/*    */ 
/*    */ public class WinConnection
/*    */   extends Connection {
/*    */   private final RandomAccessFile raf;
/*    */   private final Consumer<Packet> callback;
/*    */   
/*    */   WinConnection(String name, Consumer<Packet> callback) throws IOException {
/* 18 */     this.raf = new RandomAccessFile(name, "rw");
/* 19 */     this.callback = callback;
/*    */     
/* 21 */     Thread thread = new Thread(this::run);
/* 22 */     thread.setName("Discord IPC - Read thread");
/* 23 */     thread.start();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(ByteBuffer buffer) {
/*    */     try {
/* 29 */       this.raf.write(buffer.array());
/* 30 */     } catch (IOException e) {
/* 31 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   private void run() {
/* 36 */     ByteBuffer intB = ByteBuffer.allocate(4);
/*    */ 
/*    */     
/*    */     try {
/*    */       while (true) {
/* 41 */         readFully(intB);
/* 42 */         Opcode opcode = Opcode.valueOf(Integer.reverseBytes(intB.getInt(0)));
/*    */ 
/*    */         
/* 45 */         readFully(intB);
/* 46 */         int length = Integer.reverseBytes(intB.getInt(0));
/*    */ 
/*    */         
/* 49 */         ByteBuffer dataB = ByteBuffer.allocate(length);
/* 50 */         readFully(dataB);
/* 51 */         String data = Charset.defaultCharset().decode(dataB.rewind()).toString();
/*    */ 
/*    */         
/* 54 */         this.callback.accept(new Packet(opcode, JsonParser.parseString(data).getAsJsonObject()));
/*    */       } 
/* 56 */     } catch (Exception exception) {
/*    */       return;
/*    */     } 
/*    */   } private void readFully(ByteBuffer buffer) throws IOException {
/* 60 */     buffer.rewind();
/*    */     
/* 62 */     while (this.raf.length() < buffer.remaining()) {
/* 63 */       Thread.onSpinWait();
/*    */       try {
/* 65 */         Thread.sleep(100L);
/* 66 */       } catch (InterruptedException e) {
/* 67 */         e.printStackTrace();
/*    */       } 
/*    */     } 
/*    */     
/* 71 */     for (; buffer.hasRemaining(); this.raf.getChannel().read(buffer));
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/*    */     try {
/* 77 */       this.raf.close();
/* 78 */     } catch (IOException e) {
/* 79 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\discordipc\connection\WinConnection.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */