/*    */ package meteordevelopment.discordipc.connection;
/*    */ 
/*    */ import com.google.gson.JsonObject;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.UUID;
/*    */ import java.util.function.Consumer;
/*    */ import meteordevelopment.discordipc.Opcode;
/*    */ import meteordevelopment.discordipc.Packet;
/*    */ 
/*    */ public abstract class Connection
/*    */ {
/* 13 */   private static final String[] UNIX_TEMP_PATHS = new String[] { "XDG_RUNTIME_DIR", "TMPDIR", "TMP", "TEMP" };
/*    */   
/*    */   public static Connection open(Consumer<Packet> callback) {
/* 16 */     String os = System.getProperty("os.name").toLowerCase();
/*    */ 
/*    */     
/* 19 */     if (os.contains("win")) {
/* 20 */       for (int i = 0; i < 10; i++) {
/*    */         try {
/* 22 */           return new WinConnection("\\\\?\\pipe\\discord-ipc-" + i, callback);
/* 23 */         } catch (IOException iOException) {}
/*    */       }
/*    */     
/*    */     } else {
/*    */       
/* 28 */       String name = null;
/*    */       
/* 30 */       for (String tempPath : UNIX_TEMP_PATHS) {
/* 31 */         name = System.getenv(tempPath);
/* 32 */         if (name != null)
/*    */           break; 
/*    */       } 
/* 35 */       if (name == null) name = "/tmp"; 
/* 36 */       name = name + "/discord-ipc-";
/*    */       
/* 38 */       for (int i = 0; i < 10; i++) {
/*    */         try {
/* 40 */           return new UnixConnection(name + name, callback);
/* 41 */         } catch (IOException iOException) {}
/*    */       } 
/*    */     } 
/*    */     
/* 45 */     return null;
/*    */   }
/*    */   
/*    */   public void write(Opcode opcode, JsonObject o) {
/* 49 */     o.addProperty("nonce", UUID.randomUUID().toString());
/*    */     
/* 51 */     byte[] d = o.toString().getBytes();
/* 52 */     ByteBuffer packet = ByteBuffer.allocate(d.length + 8);
/* 53 */     packet.putInt(Integer.reverseBytes(opcode.ordinal()));
/* 54 */     packet.putInt(Integer.reverseBytes(d.length));
/* 55 */     packet.put(d);
/*    */     
/* 57 */     packet.rewind();
/* 58 */     write(packet);
/*    */   }
/*    */   
/*    */   protected abstract void write(ByteBuffer paramByteBuffer);
/*    */   
/*    */   public abstract void close();
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\discordipc\connection\Connection.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */