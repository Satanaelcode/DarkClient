/*     */ package meteordevelopment.discordipc.connection;
/*     */ 
/*     */ import com.google.gson.JsonParser;
/*     */ import java.io.IOException;
/*     */ import java.net.UnixDomainSocketAddress;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.Selector;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.function.Consumer;
/*     */ import meteordevelopment.discordipc.Opcode;
/*     */ import meteordevelopment.discordipc.Packet;
/*     */ 
/*     */ public class UnixConnection
/*     */   extends Connection
/*     */ {
/*     */   private final Selector s;
/*     */   private final SocketChannel sc;
/*     */   private final Consumer<Packet> callback;
/*     */   
/*     */   public UnixConnection(String name, Consumer<Packet> callback) throws IOException {
/*  22 */     this.s = Selector.open();
/*  23 */     this.sc = SocketChannel.open(UnixDomainSocketAddress.of(name));
/*  24 */     this.callback = callback;
/*     */     
/*  26 */     this.sc.configureBlocking(false);
/*  27 */     this.sc.register(this.s, 1);
/*     */     
/*  29 */     Thread thread = new Thread(this::run);
/*  30 */     thread.setName("Discord IPC - Read thread");
/*  31 */     thread.start();
/*     */   }
/*     */   
/*     */   private void run() {
/*  35 */     State state = State.Opcode;
/*     */     
/*  37 */     ByteBuffer intB = ByteBuffer.allocate(4);
/*  38 */     ByteBuffer dataB = null;
/*     */     
/*  40 */     Opcode opcode = null;
/*     */     try {
/*     */       while (true) {
/*     */         String data;
/*  44 */         this.s.select();
/*     */         
/*  46 */         switch (state) {
/*     */           case Opcode:
/*  48 */             this.sc.read(intB);
/*  49 */             if (intB.hasRemaining())
/*     */               continue; 
/*  51 */             opcode = Opcode.valueOf(Integer.reverseBytes(intB.getInt(0)));
/*  52 */             state = State.Length;
/*     */             
/*  54 */             intB.rewind();
/*     */           
/*     */           case Length:
/*  57 */             this.sc.read(intB);
/*  58 */             if (intB.hasRemaining())
/*     */               continue; 
/*  60 */             dataB = ByteBuffer.allocate(Integer.reverseBytes(intB.getInt(0)));
/*  61 */             state = State.Data;
/*     */             
/*  63 */             intB.rewind();
/*     */           
/*     */           case Data:
/*  66 */             this.sc.read(dataB);
/*  67 */             if (dataB.hasRemaining())
/*     */               continue; 
/*  69 */             data = Charset.defaultCharset().decode(dataB.rewind()).toString();
/*  70 */             this.callback.accept(new Packet(opcode, JsonParser.parseString(data).getAsJsonObject()));
/*     */             
/*  72 */             dataB = null;
/*  73 */             state = State.Opcode;
/*     */         } 
/*     */       
/*     */       } 
/*  77 */     } catch (Exception exception) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */   protected void write(ByteBuffer buffer) {
/*     */     try {
/*  83 */       this.sc.write(buffer);
/*  84 */     } catch (IOException e) {
/*  85 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     try {
/*  92 */       this.s.close();
/*  93 */       this.sc.close();
/*  94 */     } catch (IOException e) {
/*  95 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private enum State {
/* 100 */     Opcode,
/* 101 */     Length,
/* 102 */     Data;
/*     */   }
/*     */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\discordipc\connection\UnixConnection.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */