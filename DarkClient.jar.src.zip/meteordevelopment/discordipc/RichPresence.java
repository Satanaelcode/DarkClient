/*    */ package meteordevelopment.discordipc;
/*    */ 
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ 
/*    */ public class RichPresence {
/*    */   private String details;
/*    */   private String state;
/*    */   private Assets assets;
/*    */   private Timestamps timestamps;
/*    */   
/*    */   public void setDetails(String details) {
/* 13 */     this.details = details;
/*    */   }
/*    */   
/*    */   public void setState(String state) {
/* 17 */     this.state = state;
/*    */   }
/*    */   
/*    */   public void setLargeImage(String key, String text) {
/* 21 */     if (this.assets == null) this.assets = new Assets(); 
/* 22 */     this.assets.large_image = key;
/* 23 */     this.assets.large_text = text;
/*    */   }
/*    */   
/*    */   public void setSmallImage(String key, String text) {
/* 27 */     if (this.assets == null) this.assets = new Assets(); 
/* 28 */     this.assets.small_image = key;
/* 29 */     this.assets.small_text = text;
/*    */   }
/*    */   
/*    */   public void setStart(long time) {
/* 33 */     if (this.timestamps == null) this.timestamps = new Timestamps(); 
/* 34 */     this.timestamps.start = Long.valueOf(time);
/*    */   }
/*    */   
/*    */   public void setEnd(long time) {
/* 38 */     if (this.timestamps == null) this.timestamps = new Timestamps(); 
/* 39 */     this.timestamps.end = Long.valueOf(time);
/*    */   }
/*    */ 
/*    */   
/*    */   public JsonObject toJson() {
/* 44 */     JsonObject o = new JsonObject();
/*    */     
/* 46 */     if (this.details != null) o.addProperty("details", this.details); 
/* 47 */     if (this.state != null) o.addProperty("state", this.state);
/*    */ 
/*    */     
/* 50 */     if (this.assets != null) {
/* 51 */       JsonObject a = new JsonObject();
/*    */       
/* 53 */       if (this.assets.large_image != null) a.addProperty("large_image", this.assets.large_image); 
/* 54 */       if (this.assets.large_text != null) a.addProperty("large_text", this.assets.large_text); 
/* 55 */       if (this.assets.small_image != null) a.addProperty("small_image", this.assets.small_image); 
/* 56 */       if (this.assets.small_text != null) a.addProperty("small_text", this.assets.small_text);
/*    */       
/* 58 */       o.add("assets", (JsonElement)a);
/*    */     } 
/*    */ 
/*    */     
/* 62 */     if (this.timestamps != null) {
/* 63 */       JsonObject t = new JsonObject();
/*    */       
/* 65 */       if (this.timestamps.start != null) t.addProperty("start", this.timestamps.start); 
/* 66 */       if (this.timestamps.end != null) t.addProperty("end", this.timestamps.end);
/*    */       
/* 68 */       o.add("timestamps", (JsonElement)t);
/*    */     } 
/*    */     
/* 71 */     return o;
/*    */   }
/*    */   
/*    */   public static class Assets {
/*    */     public String large_image;
/*    */     public String large_text;
/*    */     public String small_image;
/*    */     public String small_text;
/*    */   }
/*    */   
/*    */   public static class Timestamps {
/*    */     public Long start;
/*    */     public Long end;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\meteordevelopment\discordipc\RichPresence.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */