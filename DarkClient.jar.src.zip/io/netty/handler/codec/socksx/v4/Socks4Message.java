package io.netty.handler.codec.socksx.v4;

import io.netty.handler.codec.socksx.SocksMessage;

public interface Socks4Message extends SocksMessage {}


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\io\netty\handler\codec\socksx\v4\Socks4Message.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */