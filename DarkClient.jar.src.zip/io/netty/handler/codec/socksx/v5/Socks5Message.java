package io.netty.handler.codec.socksx.v5;

import io.netty.handler.codec.socksx.SocksMessage;

public interface Socks5Message extends SocksMessage {}


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\io\netty\handler\codec\socksx\v5\Socks5Message.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */