/*    */ package io.netty.handler.codec.socks;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SocksRequestType
/*    */ {
/* 23 */   INIT,
/* 24 */   AUTH,
/* 25 */   CMD,
/* 26 */   UNKNOWN;
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\io\netty\handler\codec\socks\SocksRequestType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */