package javax.annotation.meta;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Documented
@Target({ElementType.ANNOTATION_TYPE})
public @interface TypeQualifierNickname {}


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\javax\annotation\meta\TypeQualifierNickname.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */