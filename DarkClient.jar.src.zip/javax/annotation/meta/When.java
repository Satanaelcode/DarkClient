/*    */ package javax.annotation.meta;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum When
/*    */ {
/* 15 */   ALWAYS,
/*    */   
/* 17 */   UNKNOWN,
/*    */   
/* 19 */   MAYBE,
/*    */   
/* 21 */   NEVER;
/*    */ }


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\javax\annotation\meta\When.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */