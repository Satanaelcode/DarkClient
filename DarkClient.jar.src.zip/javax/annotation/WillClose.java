package javax.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface WillClose {}


/* Location:              C:\Users\Shees\Downloads\DarkClient.jar!\javax\annotation\WillClose.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */